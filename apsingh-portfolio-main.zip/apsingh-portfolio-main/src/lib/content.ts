import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export type Accent = "primary" | "sky" | "grape" | "leaf" | "accent";

export function accentColor(accent: string): string {
  switch (accent) {
    case "sky":
      return "var(--c-sky)";
    case "grape":
    case "accent":
      return "var(--c-grape)";
    case "leaf":
      return "var(--c-leaf)";
    default:
      return "var(--c-primary)";
  }
}

export interface Project {
  id: string;
  title: string;
  emoji: string;
  badge: string;
  accent: string;
  description: string;
  technologies: string[];
  github: string;
  live_demo: string;
  sort_order: number;
}

export interface Internship {
  id: string;
  company: string;
  role: string;
  period: string;
  accent: string;
  details: string;
  sort_order: number;
}

export interface Skill {
  id: string;
  category: string;
  icon: string;
  accent: string;
  items: string[];
  sort_order: number;
}

export interface Certification {
  id: string;
  title: string;
  issuer: string;
  status: string;
  accent: string;
  description: string;
  tags: string[];
  url: string;
  sort_order: number;
}

export interface Achievement {
  id: string;
  emoji: string;
  title: string;
  subtitle: string;
  accent: string;
  details: string;
  sort_order: number;
}

export interface SocialLink {
  id: string;
  platform: string;
  icon: string;
  url: string;
  label: string;
  sort_order: number;
}

export interface ContactMessage {
  id: string;
  name: string;
  email: string;
  subject: string;
  message: string;
  is_read: boolean;
  created_at: string;
}

export interface Profile {
  name: string;
  tagline: string;
  headlineTop: string;
  headlineAccent: string;
  bio: string;
  photo: string;
  cgpa: string;
  email: string;
  phone: string;
  resumeUrl: string;
}

async function fetchTable<T>(table: string): Promise<T[]> {
  const { data, error } = await supabase
    .from(table as never)
    .select("*")
    .order("sort_order", { ascending: true });
  if (error) throw error;
  return (data ?? []) as T[];
}

async function fetchSetting<T>(key: string): Promise<T | null> {
  const { data, error } = await supabase
    .from("site_settings")
    .select("value")
    .eq("key", key)
    .maybeSingle();
  if (error) throw error;
  return (data?.value ?? null) as T | null;
}

export const useProjects = () =>
  useQuery({ queryKey: ["projects"], queryFn: () => fetchTable<Project>("projects") });
export const useInternships = () =>
  useQuery({ queryKey: ["internships"], queryFn: () => fetchTable<Internship>("internships") });
export const useSkills = () =>
  useQuery({ queryKey: ["skills"], queryFn: () => fetchTable<Skill>("skills") });
export const useCertifications = () =>
  useQuery({ queryKey: ["certifications"], queryFn: () => fetchTable<Certification>("certifications") });
export const useAchievements = () =>
  useQuery({ queryKey: ["achievements"], queryFn: () => fetchTable<Achievement>("achievements") });
export const useSocialLinks = () =>
  useQuery({ queryKey: ["social_links"], queryFn: () => fetchTable<SocialLink>("social_links") });

export const useProfile = () =>
  useQuery({ queryKey: ["setting", "profile"], queryFn: () => fetchSetting<Profile>("profile") });
export const useStatsSetting = () =>
  useQuery({
    queryKey: ["setting", "stats"],
    queryFn: () => fetchSetting<{ items: { label: string; value: number; suffix: string }[] }>("stats"),
  });
export const useMarquee = () =>
  useQuery({ queryKey: ["setting", "marquee"], queryFn: () => fetchSetting<{ items: string[] }>("marquee") });
export const useContactIntro = () =>
  useQuery({ queryKey: ["setting", "contact_intro"], queryFn: () => fetchSetting<{ text: string }>("contact_intro") });
