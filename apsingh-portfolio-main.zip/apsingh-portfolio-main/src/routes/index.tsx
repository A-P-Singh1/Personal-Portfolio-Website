import { createFileRoute } from "@tanstack/react-router";
import { Navbar } from "@/components/Navbar";
import { Hero } from "@/components/Hero";
import { Marquee } from "@/components/Marquee";
import { Stats } from "@/components/Stats";
import { About } from "@/components/About";
import { Skills } from "@/components/Skills";
import { Projects } from "@/components/Projects";
import { Internships } from "@/components/Internships";
import { Certifications } from "@/components/Certifications";
import { Contact } from "@/components/Contact";
import { Footer } from "@/components/Footer";
import { ScrollToTop } from "@/components/ScrollToTop";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Adi — Full Stack Developer Portfolio" },
      {
        name: "description",
        content:
          "Adi is a Full Stack Developer building fast, modern web apps with React, Node.js and MongoDB. Explore projects, skills and get in touch.",
      },
      { property: "og:title", content: "Adi — Full Stack Developer Portfolio" },
      {
        property: "og:description",
        content: "Modern full-stack portfolio showcasing projects, skills and experience.",
      },
      { property: "og:type", content: "website" },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <div className="min-h-screen">
      <Navbar />
      <main>
        <Hero />
        <Marquee />
        <Stats />
        <About />
        <Skills />
        <Projects />
        <Internships />
        <Certifications />
        <Contact />
      </main>
      <Footer />
      <ScrollToTop />
    </div>
  );
}
