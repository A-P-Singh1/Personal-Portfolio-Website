import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { LogOut, Trash2, Plus, Save, Mail } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { supabase } from "@/integrations/supabase/client";
import type { ContactMessage } from "@/lib/content";

export const Route = createFileRoute("/admin")({
  head: () => ({ meta: [{ title: "Admin Dashboard" }, { name: "robots", content: "noindex" }] }),
  component: AdminPage,
});

type FieldType = "text" | "textarea" | "array" | "number";
interface FieldDef {
  key: string;
  label: string;
  type: FieldType;
}

interface TableConfig {
  table: string;
  label: string;
  fields: FieldDef[];
}

const ACCENT = { key: "accent", label: "Accent (primary/sky/grape/leaf)", type: "text" as const };

const CONFIGS: TableConfig[] = [
  {
    table: "projects",
    label: "Projects",
    fields: [
      { key: "title", label: "Title", type: "text" },
      { key: "emoji", label: "Emoji", type: "text" },
      { key: "badge", label: "Badge", type: "text" },
      ACCENT,
      { key: "description", label: "Description", type: "textarea" },
      { key: "technologies", label: "Technologies (comma separated)", type: "array" },
      { key: "github", label: "GitHub URL", type: "text" },
      { key: "live_demo", label: "Live Demo URL", type: "text" },
      { key: "sort_order", label: "Order", type: "number" },
    ],
  },
  {
    table: "internships",
    label: "Internships",
    fields: [
      { key: "company", label: "Company", type: "text" },
      { key: "role", label: "Role", type: "text" },
      { key: "period", label: "Period", type: "text" },
      ACCENT,
      { key: "details", label: "Details", type: "textarea" },
      { key: "sort_order", label: "Order", type: "number" },
    ],
  },
  {
    table: "skills",
    label: "Skills",
    fields: [
      { key: "category", label: "Category", type: "text" },
      { key: "icon", label: "Icon", type: "text" },
      ACCENT,
      { key: "items", label: "Items (comma separated)", type: "array" },
      { key: "sort_order", label: "Order", type: "number" },
    ],
  },
  {
    table: "certifications",
    label: "Certifications",
    fields: [
      { key: "title", label: "Title", type: "text" },
      { key: "issuer", label: "Issuer", type: "text" },
      { key: "status", label: "Status", type: "text" },
      ACCENT,
      { key: "description", label: "Description", type: "textarea" },
      { key: "tags", label: "Tags (comma separated)", type: "array" },
      { key: "url", label: "Certificate URL", type: "text" },
      { key: "sort_order", label: "Order", type: "number" },
    ],
  },
  {
    table: "achievements",
    label: "Achievements",
    fields: [
      { key: "emoji", label: "Emoji", type: "text" },
      { key: "title", label: "Title", type: "text" },
      { key: "subtitle", label: "Subtitle", type: "text" },
      ACCENT,
      { key: "details", label: "Details", type: "textarea" },
      { key: "sort_order", label: "Order", type: "number" },
    ],
  },
  {
    table: "social_links",
    label: "Social Links",
    fields: [
      { key: "platform", label: "Platform", type: "text" },
      { key: "icon", label: "Icon (github/linkedin/twitter/mail/link)", type: "text" },
      { key: "url", label: "URL", type: "text" },
      { key: "label", label: "Label", type: "text" },
      { key: "sort_order", label: "Order", type: "number" },
    ],
  },
];

const PROFILE_FIELDS: FieldDef[] = [
  { key: "name", label: "Name", type: "text" },
  { key: "tagline", label: "Tagline", type: "text" },
  { key: "headlineTop", label: "Headline (top)", type: "text" },
  { key: "headlineAccent", label: "Headline (accent)", type: "text" },
  { key: "bio", label: "Bio", type: "textarea" },
  { key: "photo", label: "Photo URL", type: "text" },
  { key: "cgpa", label: "CGPA caption", type: "text" },
  { key: "email", label: "Email", type: "text" },
  { key: "phone", label: "Phone", type: "text" },
  { key: "resumeUrl", label: "Resume/CV URL", type: "text" },
];

function AdminPage() {
  const { session, isAdmin, loading, signOut } = useAuth();
  const navigate = useNavigate();
  const [tab, setTab] = useState<string>("messages");

  useEffect(() => {
    if (!loading && (!session || !isAdmin)) navigate({ to: "/login" });
  }, [loading, session, isAdmin, navigate]);

  if (loading || !session || !isAdmin) {
    return (
      <div className="flex min-h-screen items-center justify-center text-muted-foreground">Loading…</div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
          <h1 className="font-display text-xl font-bold">Admin Dashboard</h1>
          <div className="flex items-center gap-3">
            <Link to="/" className="text-sm text-muted-foreground hover:text-foreground">
              View site
            </Link>
            <button
              onClick={() => signOut().then(() => navigate({ to: "/login" }))}
              className="inline-flex items-center gap-1.5 rounded-lg border border-border px-3 py-1.5 text-sm hover:bg-secondary"
            >
              <LogOut size={15} /> Sign out
            </button>
          </div>
        </div>
      </header>

      <div className="mx-auto max-w-6xl px-6 py-6">
        <div className="mb-6 flex flex-wrap gap-2">
          {["messages", "profile", ...CONFIGS.map((c) => c.table)].map((t) => {
            const label =
              t === "messages" ? "Messages" : t === "profile" ? "Profile" : CONFIGS.find((c) => c.table === t)!.label;
            return (
              <button
                key={t}
                onClick={() => setTab(t)}
                className={`rounded-full px-3.5 py-1.5 text-sm font-medium transition-colors ${
                  tab === t ? "bg-primary text-primary-foreground" : "border border-border text-muted-foreground hover:text-foreground"
                }`}
              >
                {label}
              </button>
            );
          })}
        </div>

        {tab === "messages" && <Messages />}
        {tab === "profile" && <ProfileEditor />}
        {CONFIGS.map((c) => tab === c.table && <CrudEditor key={c.table} config={c} />)}
      </div>
    </div>
  );
}

function Messages() {
  const qc = useQueryClient();
  const { data } = useQuery({
    queryKey: ["admin_messages"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("contact_messages")
        .select("*")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return (data ?? []) as ContactMessage[];
    },
  });

  const remove = async (id: string) => {
    await supabase.from("contact_messages").delete().eq("id", id);
    qc.invalidateQueries({ queryKey: ["admin_messages"] });
  };

  if (!data?.length) {
    return <p className="text-sm text-muted-foreground">No messages yet.</p>;
  }

  return (
    <div className="space-y-4">
      {data.map((m) => (
        <div key={m.id} className="rounded-xl border border-border bg-card p-5">
          <div className="flex items-start justify-between gap-4">
            <div>
              <p className="font-semibold">
                {m.name} <span className="text-sm font-normal text-muted-foreground">· {m.email}</span>
              </p>
              {m.subject && <p className="text-sm font-medium text-accent">{m.subject}</p>}
            </div>
            <button onClick={() => remove(m.id)} className="text-muted-foreground hover:text-destructive">
              <Trash2 size={16} />
            </button>
          </div>
          <p className="mt-2 whitespace-pre-wrap text-sm text-muted-foreground">{m.message}</p>
          <p className="mt-2 text-xs text-muted-foreground">{new Date(m.created_at).toLocaleString()}</p>
          <a
            href={`mailto:${m.email}`}
            className="mt-2 inline-flex items-center gap-1.5 text-xs text-primary hover:underline"
          >
            <Mail size={13} /> Reply
          </a>
        </div>
      ))}
    </div>
  );
}

type Row = Record<string, unknown>;

function emptyRow(config: TableConfig): Row {
  const r: Row = {};
  config.fields.forEach((f) => {
    r[f.key] = f.type === "array" ? [] : f.type === "number" ? 0 : "";
  });
  return r;
}

function CrudEditor({ config }: { config: TableConfig }) {
  const qc = useQueryClient();
  const key = ["admin", config.table];
  const { data } = useQuery({
    queryKey: key,
    queryFn: async () => {
      const { data, error } = await supabase
        .from(config.table as never)
        .select("*")
        .order("sort_order", { ascending: true });
      if (error) throw error;
      return (data ?? []) as Row[];
    },
  });
  const [editing, setEditing] = useState<Row | null>(null);

  const save = async (row: Row) => {
    const payload: Row = {};
    config.fields.forEach((f) => (payload[f.key] = row[f.key]));
    if (row.id) payload.id = row.id;
    const { error } = await supabase.from(config.table as never).upsert(payload as never);
    if (error) {
      alert(error.message);
      return;
    }
    setEditing(null);
    qc.invalidateQueries({ queryKey: key });
  };

  const remove = async (id: string) => {
    await supabase.from(config.table as never).delete().eq("id", id);
    qc.invalidateQueries({ queryKey: key });
  };

  return (
    <div>
      {!editing && (
        <button
          onClick={() => setEditing(emptyRow(config))}
          className="mb-4 inline-flex items-center gap-1.5 rounded-lg bg-primary px-3.5 py-2 text-sm font-medium text-primary-foreground"
        >
          <Plus size={15} /> Add {config.label.replace(/s$/, "")}
        </button>
      )}

      {editing && <RowForm config={config} row={editing} onCancel={() => setEditing(null)} onSave={save} />}

      <div className="space-y-3">
        {data?.map((row) => (
          <div key={String(row.id)} className="flex items-center justify-between gap-4 rounded-xl border border-border bg-card p-4">
            <div className="min-w-0">
              <p className="truncate font-medium">
                {String(row[config.fields[0].key] ?? "")}
              </p>
              <p className="truncate text-sm text-muted-foreground">
                {String(row[config.fields[1]?.key] ?? "")}
              </p>
            </div>
            <div className="flex shrink-0 gap-2">
              <button onClick={() => setEditing(row)} className="rounded-lg border border-border px-3 py-1.5 text-sm hover:bg-secondary">
                Edit
              </button>
              <button onClick={() => remove(String(row.id))} className="text-muted-foreground hover:text-destructive">
                <Trash2 size={16} />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function RowForm({
  config,
  row,
  onCancel,
  onSave,
}: {
  config: TableConfig;
  row: Row;
  onCancel: () => void;
  onSave: (r: Row) => void;
}) {
  const [draft, setDraft] = useState<Row>(row);
  const set = (k: string, v: unknown) => setDraft((d) => ({ ...d, [k]: v }));

  return (
    <div className="mb-6 rounded-xl border border-border bg-card p-5">
      <div className="grid gap-4 sm:grid-cols-2">
        {config.fields.map((f) => (
          <div key={f.key} className={f.type === "textarea" ? "sm:col-span-2" : ""}>
            <label className="mb-1.5 block text-sm font-medium">{f.label}</label>
            {f.type === "textarea" ? (
              <textarea
                rows={3}
                value={String(draft[f.key] ?? "")}
                onChange={(e) => set(f.key, e.target.value)}
                className="w-full rounded-lg border border-border bg-background px-3 py-2 text-sm outline-none focus:border-primary"
              />
            ) : (
              <input
                value={
                  f.type === "array"
                    ? (Array.isArray(draft[f.key]) ? (draft[f.key] as string[]).join(", ") : "")
                    : String(draft[f.key] ?? "")
                }
                onChange={(e) =>
                  set(
                    f.key,
                    f.type === "array"
                      ? e.target.value.split(",").map((s) => s.trim()).filter(Boolean)
                      : f.type === "number"
                        ? Number(e.target.value)
                        : e.target.value,
                  )
                }
                className="w-full rounded-lg border border-border bg-background px-3 py-2 text-sm outline-none focus:border-primary"
              />
            )}
          </div>
        ))}
      </div>
      <div className="mt-4 flex gap-2">
        <button
          onClick={() => onSave(draft)}
          className="inline-flex items-center gap-1.5 rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground"
        >
          <Save size={15} /> Save
        </button>
        <button onClick={onCancel} className="rounded-lg border border-border px-4 py-2 text-sm hover:bg-secondary">
          Cancel
        </button>
      </div>
    </div>
  );
}

function ProfileEditor() {
  const qc = useQueryClient();
  const { data } = useQuery({
    queryKey: ["admin", "profile"],
    queryFn: async () => {
      const { data, error } = await supabase.from("site_settings").select("value").eq("key", "profile").maybeSingle();
      if (error) throw error;
      return (data?.value ?? {}) as Record<string, string>;
    },
  });
  const initial = useMemo(() => data ?? {}, [data]);
  const [draft, setDraft] = useState<Record<string, string> | null>(null);
  const value = draft ?? initial;

  const save = async () => {
    const { error } = await supabase.from("site_settings").upsert({ key: "profile", value });
    if (error) {
      alert(error.message);
      return;
    }
    qc.invalidateQueries({ queryKey: ["setting", "profile"] });
    qc.invalidateQueries({ queryKey: ["admin", "profile"] });
    alert("Profile saved");
  };

  return (
    <div className="rounded-xl border border-border bg-card p-5">
      <div className="grid gap-4 sm:grid-cols-2">
        {PROFILE_FIELDS.map((f) => (
          <div key={f.key} className={f.type === "textarea" ? "sm:col-span-2" : ""}>
            <label className="mb-1.5 block text-sm font-medium">{f.label}</label>
            {f.type === "textarea" ? (
              <textarea
                rows={3}
                value={value[f.key] ?? ""}
                onChange={(e) => setDraft({ ...value, [f.key]: e.target.value })}
                className="w-full rounded-lg border border-border bg-background px-3 py-2 text-sm outline-none focus:border-primary"
              />
            ) : (
              <input
                value={value[f.key] ?? ""}
                onChange={(e) => setDraft({ ...value, [f.key]: e.target.value })}
                className="w-full rounded-lg border border-border bg-background px-3 py-2 text-sm outline-none focus:border-primary"
              />
            )}
          </div>
        ))}
      </div>
      <button
        onClick={save}
        className="mt-4 inline-flex items-center gap-1.5 rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground"
      >
        <Save size={15} /> Save Profile
      </button>
    </div>
  );
}
