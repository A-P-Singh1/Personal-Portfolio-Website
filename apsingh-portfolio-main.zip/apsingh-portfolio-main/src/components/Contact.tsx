import { useState } from "react";
import { motion } from "motion/react";
import { Send, CheckCircle2 } from "lucide-react";
import { SectionHeading } from "./About";
import { supabase } from "@/integrations/supabase/client";
import { useContactIntro } from "@/lib/content";

interface FormData {
  name: string;
  email: string;
  subject: string;
  message: string;
}

export function Contact() {
  const { data: intro } = useContactIntro();
  const [data, setData] = useState<FormData>({ name: "", email: "", subject: "", message: "" });
  const [errors, setErrors] = useState<Partial<FormData>>({});
  const [sent, setSent] = useState(false);

  const validate = () => {
    const e: Partial<FormData> = {};
    if (!data.name.trim()) e.name = "Name is required";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) e.email = "Valid email required";
    if (!data.subject.trim()) e.subject = "Subject is required";
    if (data.message.trim().length < 10) e.message = "Message must be at least 10 characters";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = async (ev: React.FormEvent) => {
    ev.preventDefault();
    if (!validate()) return;
    const { error } = await supabase.from("contact_messages").insert({
      name: data.name.trim(),
      email: data.email.trim(),
      subject: data.subject.trim(),
      message: data.message.trim(),
    });
    if (error) {
      setErrors({ message: "Could not send message. Please try again." });
      return;
    }
    setSent(true);
    setData({ name: "", email: "", subject: "", message: "" });
    setTimeout(() => setSent(false), 4000);
  };

  const field = (k: keyof FormData) => ({
    value: data[k],
    onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) =>
      setData((d) => ({ ...d, [k]: e.target.value })),
  });

  return (
    <section id="contact" className="bg-secondary/30 px-6 py-20">
      <div className="mx-auto max-w-2xl">
        <SectionHeading eyebrow="Get In Touch" title="Contact Me" />
        {intro?.text && (
          <p className="mx-auto mb-8 -mt-6 max-w-xl text-center text-muted-foreground">{intro.text}</p>
        )}

        <motion.form
          onSubmit={handleSubmit}
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="space-y-5 rounded-2xl border border-border bg-card p-8 shadow-card"
        >
          <div className="grid gap-5 sm:grid-cols-2">
            <Input label="Name" placeholder="Your name" {...field("name")} error={errors.name} />
            <Input label="Email" placeholder="you@email.com" {...field("email")} error={errors.email} />
          </div>
          <Input label="Subject" placeholder="What's this about?" {...field("subject")} error={errors.subject} />
          <div>
            <label className="mb-1.5 block text-sm font-medium">Message</label>
            <textarea
              {...field("message")}
              rows={5}
              placeholder="Your message..."
              className="w-full rounded-lg border border-border bg-background px-4 py-2.5 text-sm outline-none focus:border-primary"
            />
            {errors.message && <p className="mt-1 text-xs text-destructive">{errors.message}</p>}
          </div>

          <button
            type="submit"
            className="inline-flex w-full items-center justify-center gap-2 rounded-lg bg-gradient-hero py-3 font-medium text-primary-foreground shadow-glow transition-transform hover:scale-[1.02]"
          >
            <Send size={18} /> Send Message
          </button>

          {sent && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex items-center justify-center gap-2 rounded-lg bg-primary/10 py-3 text-sm font-medium text-primary"
            >
              <CheckCircle2 size={18} /> Message sent successfully! I'll get back to you soon.
            </motion.div>
          )}
        </motion.form>
      </div>
    </section>
  );
}

function Input({
  label,
  error,
  ...props
}: { label: string; error?: string } & React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <div>
      <label className="mb-1.5 block text-sm font-medium">{label}</label>
      <input
        {...props}
        className="w-full rounded-lg border border-border bg-background px-4 py-2.5 text-sm outline-none focus:border-primary"
      />
      {error && <p className="mt-1 text-xs text-destructive">{error}</p>}
    </div>
  );
}
