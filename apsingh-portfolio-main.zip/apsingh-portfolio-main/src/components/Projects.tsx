import { useMemo, useState } from "react";
import { motion } from "motion/react";
import { Github, ExternalLink, Search } from "lucide-react";
import { useProjects, accentColor } from "@/lib/content";
import { SectionHeading } from "./About";

export function Projects() {
  const { data: projects = [] } = useProjects();
  const [query, setQuery] = useState("");
  const [tech, setTech] = useState("All");

  const allTech = useMemo(
    () => ["All", ...Array.from(new Set(projects.flatMap((p) => p.technologies)))],
    [projects],
  );

  const filtered = projects.filter((p) => {
    const matchQuery =
      p.title.toLowerCase().includes(query.toLowerCase()) ||
      p.description.toLowerCase().includes(query.toLowerCase());
    const matchTech = tech === "All" || p.technologies.includes(tech);
    return matchQuery && matchTech;
  });

  return (
    <section id="projects" className="px-6 py-20">
      <div className="mx-auto max-w-6xl">
        <SectionHeading eyebrow="My Work" title="Featured Projects" />

        <div className="mb-10 flex flex-col items-center gap-4 sm:flex-row sm:justify-between">
          <div className="relative w-full sm:max-w-xs">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" size={16} />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search projects..."
              className="w-full rounded-lg border border-border bg-card py-2.5 pl-9 pr-3 text-sm outline-none focus:border-primary"
            />
          </div>
          <div className="flex flex-wrap gap-2">
            {allTech.map((t) => (
              <button
                key={t}
                onClick={() => setTech(t)}
                className={`rounded-full px-3 py-1.5 text-xs font-medium transition-colors ${
                  tech === t
                    ? "bg-gradient-hero text-primary-foreground"
                    : "border border-border text-muted-foreground hover:text-foreground"
                }`}
              >
                {t}
              </button>
            ))}
          </div>
        </div>

        <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((p, i) => (
            <motion.article
              key={p.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: i * 0.08 }}
              whileHover={{ y: -6 }}
              className="group flex flex-col overflow-hidden rounded-2xl border border-border bg-card shadow-card"
            >
              <div
                className="flex h-40 items-center justify-center text-6xl"
                style={{ background: `color-mix(in oklab, ${accentColor(p.accent)} 12%, transparent)` }}
              >
                <span>{p.emoji || "🚀"}</span>
              </div>
              <div className="flex flex-1 flex-col p-6">
                <div className="flex items-center justify-between gap-2">
                  <h3 className="font-display text-xl font-semibold">{p.title}</h3>
                  {p.badge && (
                    <span
                      className="shrink-0 rounded-full px-2.5 py-1 text-[10px] font-semibold uppercase tracking-wide text-primary-foreground"
                      style={{ background: accentColor(p.accent) }}
                    >
                      {p.badge}
                    </span>
                  )}
                </div>
                <p className="mt-2 text-sm text-muted-foreground">{p.description}</p>
                <div className="mt-4 flex flex-wrap gap-2">
                  {p.technologies.map((t) => (
                    <span key={t} className="rounded-full bg-primary/10 px-2.5 py-1 text-xs font-medium text-primary">
                      {t}
                    </span>
                  ))}
                </div>
                <div className="mt-5 flex gap-4 text-sm font-medium">
                  {p.github && (
                    <a href={p.github} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1.5 text-muted-foreground hover:text-foreground">
                      <Github size={16} /> Code
                    </a>
                  )}
                  {p.live_demo && (
                    <a href={p.live_demo} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1.5 text-primary hover:underline">
                      <ExternalLink size={16} /> Live Demo
                    </a>
                  )}
                </div>
              </div>
            </motion.article>
          ))}
        </div>

        {filtered.length === 0 && (
          <p className="text-center text-muted-foreground">No projects match your search.</p>
        )}
      </div>
    </section>
  );
}
