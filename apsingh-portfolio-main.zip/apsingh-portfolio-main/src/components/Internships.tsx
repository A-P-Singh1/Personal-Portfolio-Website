import { motion } from "motion/react";
import { Briefcase } from "lucide-react";
import { useInternships, accentColor } from "@/lib/content";
import { SectionHeading } from "./About";

export function Internships() {
  const { data: internships = [] } = useInternships();
  if (!internships.length) return null;

  return (
    <section id="internships" className="bg-secondary/30 px-6 py-20">
      <div className="mx-auto max-w-4xl">
        <SectionHeading eyebrow="Experience" title="Internships" />
        <div className="relative border-l border-border pl-8">
          {internships.map((item, i) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: i * 0.1 }}
              className="relative mb-10 last:mb-0"
            >
              <span
                className="absolute -left-[2.6rem] mt-1 flex h-7 w-7 items-center justify-center rounded-full ring-4 ring-background"
                style={{ background: accentColor(item.accent) }}
              >
                <Briefcase size={13} className="text-primary-foreground" />
              </span>
              <span className="text-sm font-semibold text-accent">{item.period}</span>
              <h4 className="font-display text-lg font-semibold">{item.role}</h4>
              <p className="text-sm font-medium text-muted-foreground">{item.company}</p>
              {item.details && <p className="mt-1 text-sm text-muted-foreground">{item.details}</p>}
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
