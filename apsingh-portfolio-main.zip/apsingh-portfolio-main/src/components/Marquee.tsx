import { useMarquee } from "@/lib/content";

export function Marquee() {
  const { data } = useMarquee();
  const items = data?.items ?? [];
  if (!items.length) return null;
  const loop = [...items, ...items];

  return (
    <section className="overflow-hidden border-y border-border bg-secondary/30 py-5">
      <div className="flex w-max animate-marquee gap-12">
        {loop.map((item, i) => (
          <span
            key={i}
            className="font-display text-lg font-semibold text-muted-foreground"
          >
            {item}
          </span>
        ))}
      </div>
    </section>
  );
}
