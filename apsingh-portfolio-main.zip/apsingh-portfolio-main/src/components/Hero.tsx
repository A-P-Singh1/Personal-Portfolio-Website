import { useEffect, useState } from "react";
import { motion } from "motion/react";
import { ArrowRight, Download, Github, Linkedin, Twitter, Mail, Link as LinkIcon } from "lucide-react";
import { useProfile, useSocialLinks, type SocialLink } from "@/lib/content";

function useTyping(words: string[]) {
  const [text, setText] = useState("");
  const [idx, setIdx] = useState(0);
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    if (!words.length) return;
    const current = words[idx % words.length];
    const speed = deleting ? 50 : 110;
    const timer = setTimeout(() => {
      if (!deleting) {
        setText(current.slice(0, text.length + 1));
        if (text.length + 1 === current.length) setTimeout(() => setDeleting(true), 1400);
      } else {
        setText(current.slice(0, text.length - 1));
        if (text.length === 0) {
          setDeleting(false);
          setIdx((i) => (i + 1) % words.length);
        }
      }
    }, speed);
    return () => clearTimeout(timer);
  }, [text, deleting, idx, words]);

  return text;
}

const ICONS: Record<string, typeof Github> = {
  github: Github,
  linkedin: Linkedin,
  twitter: Twitter,
  mail: Mail,
  link: LinkIcon,
};

function SocialIcons({ links }: { links: SocialLink[] }) {
  return (
    <div className="mt-8 flex gap-3">
      {links.map((s) => {
        const Icon = ICONS[s.icon] ?? LinkIcon;
        const external = s.url.startsWith("http");
        return (
          <a
            key={s.id}
            href={s.url}
            aria-label={s.platform}
            target={external ? "_blank" : undefined}
            rel="noreferrer"
            className="rounded-lg border border-border p-2.5 text-muted-foreground transition-colors hover:border-primary hover:text-primary"
          >
            <Icon size={18} />
          </a>
        );
      })}
    </div>
  );
}

export function Hero() {
  const { data: profile } = useProfile();
  const { data: socials = [] } = useSocialLinks();
  const tagline = profile?.tagline ?? "Full Stack Developer";
  const typed = useTyping(tagline.split(/\s*[&·,]\s*|\s{2,}/).filter(Boolean));

  return (
    <section id="home" className="relative overflow-hidden px-6 pt-32 pb-20">
      <div className="absolute -top-40 left-1/2 -z-10 h-96 w-96 -translate-x-1/2 rounded-full bg-primary/20 blur-3xl" />
      <div className="mx-auto grid max-w-6xl items-center gap-12 md:grid-cols-2">
        <motion.div
          initial={{ opacity: 0, x: -40 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6 }}
        >
          <p className="mb-3 font-medium text-accent">Hi, I'm</p>
          <h1 className="font-display text-5xl font-bold sm:text-6xl">{profile?.name ?? "Portfolio"}</h1>
          <h2 className="mt-3 h-9 text-xl font-semibold text-muted-foreground sm:text-2xl">
            <span className="text-gradient">{typed}</span>
            <span className="animate-pulse">|</span>
          </h2>
          <p className="mt-5 max-w-md text-muted-foreground">{profile?.bio}</p>
          {profile?.cgpa && (
            <p className="mt-3 text-sm font-medium text-accent">{profile.cgpa}</p>
          )}

          <div className="mt-8 flex flex-wrap gap-4">
            <a
              href="#projects"
              className="inline-flex items-center gap-2 rounded-lg bg-gradient-hero px-6 py-3 font-medium text-primary-foreground shadow-glow transition-transform hover:scale-105"
            >
              View Projects <ArrowRight size={18} />
            </a>
            {profile?.resumeUrl && (
              <a
                href={profile.resumeUrl}
                download
                className="inline-flex items-center gap-2 rounded-lg border border-border px-6 py-3 font-medium transition-colors hover:bg-secondary"
              >
                <Download size={18} /> Download Resume
              </a>
            )}
          </div>

          <SocialIcons links={socials} />
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="relative mx-auto"
        >
          <div className="absolute inset-0 -z-10 rounded-3xl bg-gradient-hero blur-2xl opacity-40" />
          {profile?.photo ? (
            <img
              src={profile.photo}
              alt={profile?.name ?? "Profile"}
              width={384}
              height={384}
              className="h-72 w-72 rounded-3xl object-cover shadow-card ring-1 ring-border sm:h-96 sm:w-96"
            />
          ) : (
            <div className="flex h-72 w-72 items-center justify-center rounded-3xl bg-gradient-hero text-7xl font-display font-bold text-primary-foreground shadow-card ring-1 ring-border sm:h-96 sm:w-96">
              {(profile?.name ?? "?")
                .split(" ")
                .map((w) => w[0])
                .join("")
                .slice(0, 2)
                .toUpperCase()}
            </div>
          )}
        </motion.div>
      </div>
    </section>
  );
}
