import { useEffect, useRef, useState } from "react";
import { useInView } from "react-intersection-observer";
import { useStatsSetting } from "@/lib/content";

function Counter({ value, suffix }: { value: number; suffix: string }) {
  const [count, setCount] = useState(0);
  const { ref, inView } = useInView({ triggerOnce: true, threshold: 0.5 });
  const started = useRef(false);

  useEffect(() => {
    if (!inView || started.current) return;
    started.current = true;
    const duration = 1500;
    const start = performance.now();
    const step = (now: number) => {
      const p = Math.min((now - start) / duration, 1);
      setCount(Math.floor(p * value));
      if (p < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  }, [inView, value]);

  return (
    <span ref={ref} className="text-gradient font-display text-5xl font-bold">
      {count}
      {suffix}
    </span>
  );
}

export function Stats() {
  const { data } = useStatsSetting();
  const items = data?.items ?? [];
  if (!items.length) return null;

  return (
    <section className="px-6 py-16">
      <div className="mx-auto grid max-w-4xl gap-8 rounded-2xl border border-border bg-card p-10 shadow-card sm:grid-cols-3">
        {items.map((s) => (
          <div key={s.label} className="text-center">
            <Counter value={s.value} suffix={s.suffix} />
            <p className="mt-2 text-sm text-muted-foreground">{s.label}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
