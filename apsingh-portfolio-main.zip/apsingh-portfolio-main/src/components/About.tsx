import { motion } from "motion/react";
import { GraduationCap, Award, Target } from "lucide-react";
import { useProfile, useAchievements, accentColor } from "@/lib/content";

export function About() {
  const { data: profile } = useProfile();
  const { data: achievements = [] } = useAchievements();

  return (
    <section id="about" className="px-6 py-20">
      <div className="mx-auto max-w-6xl">
        <SectionHeading eyebrow="About Me" title="My Journey" />

        <div className="grid gap-12 md:grid-cols-2">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <p className="text-muted-foreground">{profile?.bio}</p>
            <div className="mt-6 space-y-4">
              <Goal icon={Target} title="Tagline" desc={profile?.tagline ?? ""} />
              <Goal icon={GraduationCap} title="Academics" desc={profile?.cgpa ?? ""} />
              <Goal
                icon={Award}
                title="Contact"
                desc={[profile?.email, profile?.phone].filter(Boolean).join(" · ")}
              />
            </div>
          </motion.div>

          <div className="grid gap-4 sm:grid-cols-2 md:grid-cols-1 lg:grid-cols-2">
            {achievements.map((a, i) => (
              <motion.div
                key={a.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: i * 0.1 }}
                className="rounded-2xl border border-border bg-card p-6 shadow-card"
              >
                <div className="text-3xl">{a.emoji}</div>
                <h4 className="mt-3 font-display text-lg font-semibold" style={{ color: accentColor(a.accent) }}>
                  {a.title}
                </h4>
                <p className="text-sm font-medium text-muted-foreground">{a.subtitle}</p>
                {a.details && <p className="mt-1 text-sm text-muted-foreground">{a.details}</p>}
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

function Goal({ icon: Icon, title, desc }: { icon: typeof Target; title: string; desc: string }) {
  return (
    <div className="flex gap-4">
      <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary">
        <Icon size={20} />
      </div>
      <div>
        <h4 className="font-semibold">{title}</h4>
        <p className="text-sm text-muted-foreground">{desc}</p>
      </div>
    </div>
  );
}

export function SectionHeading({ eyebrow, title }: { eyebrow: string; title: string }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5 }}
      className="mb-12 text-center"
    >
      <p className="font-medium text-accent">{eyebrow}</p>
      <h2 className="mt-2 font-display text-4xl font-bold">{title}</h2>
      <div className="mx-auto mt-4 h-1 w-20 rounded-full bg-gradient-hero" />
    </motion.div>
  );
}
