import { Github, Linkedin, Twitter, Mail, Link as LinkIcon } from "lucide-react";
import { useProfile, useSocialLinks } from "@/lib/content";

const ICONS: Record<string, typeof Github> = {
  github: Github,
  linkedin: Linkedin,
  twitter: Twitter,
  mail: Mail,
  link: LinkIcon,
};

export function Footer() {
  const { data: profile } = useProfile();
  const { data: socials = [] } = useSocialLinks();
  const name = profile?.name ?? "Portfolio";

  return (
    <footer className="border-t border-border px-6 py-10">
      <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-6 sm:flex-row">
        <a href="#home" className="font-display text-lg font-bold">
          {name}
          <span className="text-accent">.</span>
        </a>
        <div className="flex gap-3">
          {socials.map((s) => {
            const Icon = ICONS[s.icon] ?? LinkIcon;
            const external = s.url.startsWith("http");
            return (
              <a
                key={s.id}
                href={s.url}
                aria-label={s.platform}
                target={external ? "_blank" : undefined}
                rel="noreferrer"
                className="rounded-lg border border-border p-2.5 text-muted-foreground transition-colors hover:border-primary hover:text-primary"
              >
                <Icon size={18} />
              </a>
            );
          })}
        </div>
        <p className="text-sm text-muted-foreground">
          © {new Date().getFullYear()} {name}. All rights reserved.
        </p>
      </div>
    </footer>
  );
}
