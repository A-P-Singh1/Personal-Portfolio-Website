import { motion } from "motion/react";
import { useSkills } from "@/lib/content";
import { accentColor } from "@/lib/content";
import { SectionHeading } from "./About";

export function Skills() {
  const { data: skills = [] } = useSkills();

  return (
    <section id="skills" className="bg-secondary/30 px-6 py-20">
      <div className="mx-auto max-w-6xl">
        <SectionHeading eyebrow="What I Know" title="Skills & Expertise" />
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {skills.map((skill, i) => (
            <motion.div
              key={skill.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: i * 0.05 }}
              className="rounded-2xl border border-border bg-card p-6 shadow-card"
            >
              <div className="mb-4 flex items-center gap-2">
                <span
                  className="h-2.5 w-2.5 rounded-full"
                  style={{ background: accentColor(skill.accent) }}
                />
                <h3 className="font-display text-lg font-semibold">{skill.category}</h3>
              </div>
              <div className="flex flex-wrap gap-2">
                {skill.items.map((item) => (
                  <span
                    key={item}
                    className="rounded-full bg-primary/10 px-3 py-1 text-xs font-medium text-primary"
                  >
                    {item}
                  </span>
                ))}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
