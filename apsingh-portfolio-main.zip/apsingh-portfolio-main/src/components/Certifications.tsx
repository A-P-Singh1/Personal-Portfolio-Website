import { motion } from "motion/react";
import { ExternalLink, BadgeCheck } from "lucide-react";
import { useCertifications, accentColor } from "@/lib/content";
import { SectionHeading } from "./About";

export function Certifications() {
  const { data: certs = [] } = useCertifications();
  if (!certs.length) return null;

  return (
    <section id="certifications" className="px-6 py-20">
      <div className="mx-auto max-w-6xl">
        <SectionHeading eyebrow="Credentials" title="Certifications" />
        <div className="grid gap-6 sm:grid-cols-2">
          {certs.map((c, i) => (
            <motion.div
              key={c.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: i * 0.08 }}
              className="rounded-2xl border border-border bg-card p-6 shadow-card"
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-2">
                  <BadgeCheck size={20} style={{ color: accentColor(c.accent) }} />
                  <h3 className="font-display text-lg font-semibold">{c.title}</h3>
                </div>
                <span className="shrink-0 rounded-full border border-border px-2.5 py-1 text-xs font-medium text-muted-foreground">
                  {c.status}
                </span>
              </div>
              <p className="mt-2 text-sm font-medium text-accent">{c.issuer}</p>
              {c.description && <p className="mt-2 text-sm text-muted-foreground">{c.description}</p>}
              {c.tags?.length > 0 && (
                <div className="mt-4 flex flex-wrap gap-2">
                  {c.tags.map((t) => (
                    <span key={t} className="rounded-full bg-primary/10 px-2.5 py-1 text-xs font-medium text-primary">
                      {t}
                    </span>
                  ))}
                </div>
              )}
              {c.url && (
                <a
                  href={c.url}
                  target="_blank"
                  rel="noreferrer"
                  className="mt-4 inline-flex items-center gap-1.5 text-sm font-medium text-primary hover:underline"
                >
                  <ExternalLink size={15} /> View Certificate
                </a>
              )}
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
