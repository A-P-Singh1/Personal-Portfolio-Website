import { motion } from "motion/react";

export function SectionHeading({ title, subtitle }: { title: string; subtitle?: string }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5 }}
      className="mb-8"
    >
      <div className="flex items-center gap-4">
        <p className="text-xs font-semibold uppercase tracking-[0.25em] text-accent whitespace-nowrap">
          {title}
        </p>
        <span className="h-px flex-1 bg-border" />
      </div>
      {subtitle && <p className="mt-2 text-sm text-muted-foreground">{subtitle}</p>}
    </motion.div>
  );
}
