UPDATE public.site_settings
SET value = jsonb_set(value, '{photo}', to_jsonb('/__l5e/assets-v1/fc463ed1-f708-4fd3-b583-ead5a4adc375/profile.jpg'::text))
WHERE key = 'profile';