
INSERT INTO storage.buckets (id, name, public)
VALUES ('portfolio', 'portfolio', true)
ON CONFLICT (id) DO NOTHING;

CREATE POLICY "portfolio public read" ON storage.objects
  FOR SELECT TO anon, authenticated USING (bucket_id = 'portfolio');
CREATE POLICY "portfolio admin insert" ON storage.objects
  FOR INSERT TO authenticated WITH CHECK (bucket_id = 'portfolio' AND public.has_role(auth.uid(),'admin'));
CREATE POLICY "portfolio admin update" ON storage.objects
  FOR UPDATE TO authenticated USING (bucket_id = 'portfolio' AND public.has_role(auth.uid(),'admin'));
CREATE POLICY "portfolio admin delete" ON storage.objects
  FOR DELETE TO authenticated USING (bucket_id = 'portfolio' AND public.has_role(auth.uid(),'admin'));
